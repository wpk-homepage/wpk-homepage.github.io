# A queue of (user id, tweet id) tuples.
# They can only be retrieved from the queue once every 30 minutes.
#
# @author Paul Koppen, http://paulkoppen.com/
# @email  twitwords (a) paulkoppen . com
#
# @version 0.3.0
# @date    14 February 2013
#
# 24 Sep 2012, Paul, fixed reading item set in load()
#  5 Oct 2012, Paul, added locking to allow parallel use
#  8 Oct 2012, Paul, added prepend() to extend from the queue head
# 30 Oct 2012, Paul, removed __len__()
# 22 Nov 2012, Paul, lock file is now specific to the queue file name
# 22 Nov 2012, Paul, _lock throws QueueLockedException when unable to lock
#  5 Dec 2012, Paul, complete redesign
#                    three new classes, old Queue2 removed
#                    TupleQueue is very similar to previous Queue2
#                         defines take(n) give(tt) clean() reset(tt) stats()
#                         needs regular purging to keep keys unique
#                    HeadTailQueue and ShardedQueue inherit from TupleQueue
#                    HeadTailQueue needs purging when head is empty
#                    ShardedQueue is a queue of queues, spreading load
#  6 Dec 2012, Paul, ShardedQueue _lock and _unlock raise NotImplementedError
#                    HeadTailQueue has _tail which is just another TupleQueue
#                    Auto-clean HeadTailQueue on empty head
# 11 Dec 2012, Paul, fixed ShardedQueue.stats()
#                    fixed ShardedQueue.reset() and ._reset()
#                    added logging to TupleQueue._reset()
#                    fixed ShardedQueue.clean()
#                    updated HeadTailQueue.clean() and _clean() to skip if the
#                         tail is empty. Optional argument force=True can be
#                         specified to force purging the head.
#  7 Jan 2013, Paul, added WebQueue
#  8 Jan 2013, Paul, implemented WebQueue.reset
#  9 Jan 2013, Paul, WebQueue has no clean.
# 14 Feb 2013, Paul, clean sheet
#                    TwitQueue runs in memory, has a heap queue for sorting
#                         and a dict for mapping tweet ids.
#                    TwitQueueClient has exactly the same functions, but runs
#                         them against a TwitQueueServer over a socket.
#                    TwitQueueServer exposes the TwitQueue methods over a socket
# 15 Feb 2013, Paul, added next item availability logging (in info)
#                    fixed file mode 'rb' for Windows
# 16 Feb 2013, Paul, added documentation
#                    replaced period argument to take with item_waittime in the
#                    queue constructor. take now only takes one argument: n.
#                    note that in this setup TwitQueueClient cannot control the
#                    item_waittime.
# 17 Feb 2013, Paul, fixed TwitQueue.take(0)
# 21 Feb 2013, Paul, moved load() and save() to TwitQueue
#  1 Mar 2013, Paul, changed to use cPickle
#
from   heapq                      import heappop, heappush, heappushpop
import logging
from   multiprocessing            import AuthenticationError
from   multiprocessing.connection import Client, Listener
from   os                         import path
from   cPickle                    import dump, load
from   time                       import localtime, strftime, time



################################################################################
###  QUEUE
################################################################################

class TwitQueue(object):
	def __init__(self, item_waittime=60*30, *args, **kwargs):
		# Multiple inheritance: pass on to class Listener for TwitQueueServer.
		super(TwitQueue, self).__init__(*args, **kwargs)
		self.item_waittime = item_waittime
		self.queue         = list()
		self.data          = dict()
	
	def load(self):
		""" Initialise the queue from file.
		Only do this in __init__ because you will lose all recent data.
		"""
		try:
			self.queue, self.data = load(open(self.filename, 'rb'))
		except (EOFError, IOError), e:
			if path.isfile(self.filename):
				raise e	# probably last instance crashed hard
			else:
				logging.warn('No queue file.')
	
	def save(self):
		""" Save queue to file.
		"""
		with open(self.filename, 'wb') as f:
			dump((self.queue, self.data), f, -1)
		return 'OK'
	
	def take(self, n):
		""" Lease N (userid,tweetid) tuples from the queue for some time.
		After that time anyone can request the tuples again and change them.
		@param  n     Number of desired tuples.
		@return tups  List of (uid, tid) tuples. If there are at least n
		              available on the queue, return n tuples, else as many as
		              are available.
		"""
		if n < 1: return []
		now  = int(time())
		then = now + self.item_waittime
		tups = []
		# first item may raise IndexError if the queue is empty.
		try:
			ts, uid = heappop(self.queue)
			if ts > now:
				heappush(self.queue, (ts, uid))
				logging.info('Next item can be read from queue: %s',
								strftime('%d-%m-%Y %H:%M:%S', localtime(ts)))
				raise IndexError	# and (ab)use the cunstruct here too.
		except IndexError:
			return []
		tups.append((uid, self.data[uid]))
		# heappushpop does not and we read n items with an old enough timestamp.
		for i in xrange(n-1):
			ts, uid = heappushpop(self.queue, (then, uid))
			if ts < now:
				tups.append((uid, self.data[uid]))
			else:
				then = ts
				break
		# finally put the last item back on the queue before returning tups.
		heappush(self.queue, (then, uid))
		logging.info('Next item can be read from queue ~ %s',
								strftime('%d-%m-%Y %H:%M:%S', localtime(ts)))
		return tups
	
	def update(self, tups, adduids=[]):
		""" Update tweet ID's for some user ID's.
		@param  tups     Iterable of tuples (uid, tid). All uid values must
		                 already be present on the queue and their associated
		                 tid will be updated.
		@param  adduids  Iterable (e.g. set or list) of int/long Twitter IDs.
		@return counts (tuple)  Length of the queue, number of unique tweet IDs.
		"""
		self.data.update((uid,tid) for uid,tid in tups if self.data[uid] < tid)
		self.add(adduids)
		return self.stats()
	
	def add(self, uids):
		""" Add new user ID's to the queue.
		@param uids  Iterable (e.g. set or list) of int/long twitter IDs.
		"""
		ts  = int(time())
		new = (uid for uid in uids if uid not in self.data)
		for uid in new:
			heappush(self.queue, (ts, uid))
			self.data[uid] = None
	
	def stats(self):
		""" Report some statistics on the queue.
		@return counts (tuple)  Length of the queue, number of unique tweet IDs.
		"""
		return (len(self.queue), sum(1 for tid in self.data.values() if tid))
	
	def _reset(self, tups):
		""" Initialise (reset) the queue. Take care not to erase precious data!
		Items on the queue are available immediately.
		@param tups  List of tuples (uid, tid)
		"""
		ts         = int(time())
		self.data  = dict(tups)
		self.queue = list()
		for uid, tid in tups:
			heappush(self.queue, (ts, uid))



################################################################################
###  CLIENT / SERVER
################################################################################

class TwitQueueServer(TwitQueue, Listener):
	def __init__(self, address, filename, authkey=None, item_waittime=30*60):
		super(TwitQueueServer, self).__init__(address=address, authkey=authkey,
												item_waittime=item_waittime)
		self.supportedmethods = set(m for m in dir(TwitQueue) if m[0] != '_')
		self.supportedmethods.add('quit')
		self.supportedmethods.discard('load')
		self.filename         = filename
		self.load()
		logging.info('Available methods %s', self.supportedmethods)
	
	def serve_forever(self):
		""" Listen for incoming connections to the queue.
		"""
		connection = None	# see finally block
		while True:
			try:
				connection = self.accept()		# AuthenticationError
				logging.info('Connection from %s', self.last_accepted)
				
				request = connection.recv()
				logging.debug('Request: %s', request)
				command = request[0]			# TypeError
				
				if command == 'quit':
					logging.info('Server will quit now.')
					connection.send('Bye')
					break
				elif command in self.supportedmethods:
					# the request seems valid
					# send it through to the queue
					fcn          = getattr(self, command)
					args         = request[1:]
					try:
						response = fcn(*args)
					except StandardError, e:
						# Unknown error during function evaluation
						logging.error('self.%s(*args): %s', command, repr(e))
						continue
					# and return the response
					logging.debug('Response: %s', response)
					connection.send(response)
				else:
					raise AttributeError		# AttributeError
			
			except AuthenticationError:
				logging.warn('Invalid authentication %s', self.last_accepted)
			
			except (AttributeError, TypeError):
				# Malformed request received
				logging.warn('Invalid request %s', self.last_accepted)
			
			except StandardError, e:
				# Unknown error during function evaluation
				logging.error('self.queue.%s(*args): %s', command, repr(e))
			
			finally:
				# always close the connection
				# unless we errored before there even was one (Auth)
				if connection:
					connection.close()
					connection = None
		self.save()



class TwitQueueClient(TwitQueue):
	def __init__(self, address, authkey=None):
		""" TwitQueueClient provides transparent access to a remote queue over
		a network connection. It provides all non-underscore-prefixed method of
		the queue. Rather than keeping the queue locally though, it tunnels the
		requests through to a server and returns the respons from that.
		@param address  Server address as (hostname, portnum) tuple.
		@param authkey  Optional authentication key (string). May be required
		                by the server.
		"""
		# note: cannot support item_waittime because it is a server directive.
		supportedmethods = set(m for m in dir(self) if m[0] != '_')
		supportedmethods.add('quit')
		supportedmethods.discard('load')
		self.__dict__.update((method, self._rpc_wrap(address, method, authkey))
							for method in supportedmethods)
		logging.info('Available methods %s', supportedmethods)
	
	@staticmethod
	def _rpc_wrap(address, method, authkey=None):
		""" Wrapper function to catch all TwitQueue methods and tunnel them
		to a server.
		@param address  Server address as (hostname, portnum) tuple.
		@param method   Function name on the TwitQueue.
		@param authkey  Optional authentication key (string). May be required
		                by the server
		"""
		def _rpc_call(*message):
			logging.debug('Sending %s to %s', (method,)+message, address)
			connection   = Client(address, authkey=authkey)
			connection.send((method,)+message)
			try:
				response = connection.recv()
				logging.debug('Response: %s', response)
			except EOFError:
				logging.warn('Connection closed prematurely. Returning None.')
			else:
				return response
			finally:
				connection.close()
		return _rpc_call


