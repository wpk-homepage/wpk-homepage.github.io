#
# @author Paul Koppen, http://paulkoppen.com/
# @email  twitwords (a) paulkoppen . com
#
# @version 0.3.0
# @date    15 February 2013
#
# @todo : Write tweets as tuples with pickle
# @todo : Create a reverse index from user id to tweet log file names
#
# 15 Feb 2013, Paul, added queue stats to progress log
#                    updated timestamp for tweets
# 16 Feb 2013, Paul, changed to have separate filenames for different log files
#                    passed to the class constructor.
#                    added documentation
#                    added failed / protected distinction
#
# log tweets:
#  tid,uid,ts
#  msg
#  tid,uid,ts
#  msg
#  ...
#
# log network:
#  tid,uid,uid,uid
#  tid,uid,uid
#  tid,uid
#  tid,uid,uid,uid,uid
#  ...
#
# log stats:
#  ts,crawled,failed,tweets,queue size,queue crawled,node
#  ...
#
from codecs import open
from os     import chmod
from time   import gmtime, strftime



class TwitLog(object):
	def __init__(self, name, tweets_logname, network_logname, stats_logname):
		""" TwitLog is an object to log all crawling progress.
		@param name             Name written in stats log.
		@param tweets_logname   Filename to write crawled tweets.
		@param network_logname  Filename to write userid connections.
		@param stats_logname    Filename to write progress log.
		"""
		self.name            = name
		self.tweets_logname  = tweets_logname
		self.network_logname = network_logname
		self.stats_logname   = stats_logname
	
	def write_tweets(self, tweets):
		""" Write tweets and social network to file.
		@param tweets  List of tuples (tid, uid, ts, msg, refs), where refs is
		               a list of uids referenced in the tweet, exc. uid self.
		"""
		# write texts
		ts    = strftime('%Y-%m-%d', gmtime())
		fname = self.tweets_logname % ts
		with open(fname, 'a', 'utf-8') as f:
			f.writelines('%d,%d,%s\n%s\n' % (tid, uid, 
						strftime('%Y-%m-%d %H:%M', ts), msg)
						for (tid, uid, ts, msg, refs) in tweets if msg)
		chmod(fname, 0600)
		# write social network (user ids joining on each tweet id)
		fname = self.network_logname % ts
		with open(fname, 'a', 'utf-8') as f:
			f.writelines('%d,%d,%s\n' % (tid, uid, 
						','.join(str(u) for u in refs))
						for (tid, uid, ts, msg, refs) in tweets if msg)
		chmod(fname, 0600)
	
	def write_progress(self, crawled, protected, failed, numtweets, qlen, qcrawled):
		""" Write stats to file
		@param crawled    Count timelines actually crawled
		@param protected  Count timelines that appeared to be protected
		@param failed     Count failed timelines (due to server error /overload)
		@param numtweets  Count tweets extracted from those timelines
		@param qlen       New length of the twit queue
		@param qcrawled   Total number of crawled timelines on the queue
		"""
		now   = gmtime()
		ts    = strftime('%Y-%m-%d', now)
		fname = self.stats_logname % ts
		with open(fname, 'a', 'utf-8') as f:
			f.write('%s,%d,%d,%d,%d,%d,%d,%s\n' % (
						strftime('%Y-%m-%d %H:%M', now), crawled, protected,
						failed, numtweets, qlen, qcrawled, self.name))
		chmod(fname, 0600)


