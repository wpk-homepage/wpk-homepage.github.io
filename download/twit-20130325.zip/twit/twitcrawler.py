#
# @author Paul Koppen, http://paulkoppen.com/
# @email  twitwords (a) paulkoppen . com
#
# @version 0.3.0
# @date    17 February 2013
#
# @todo : time() seems to be incompatible with lim['reset']
# @todo : what if self.api.getratelimitstatus fails because Twitter is down?
#
# 15 Feb 2013, Paul, first version after many other implementations
#                    added queue_takeperiod to config
# 16 Feb 2013, Paul, fix tweets for crawling multiple accounts
#                    added distinction between protected profiles and failed
# 19 Feb 2013, Paul, fix log.write_progress call
# 21 Feb 2013, Paul, update rate limit info from response headers after crawl
# 26 Feb 2013, Paul, catch httplib IncompleteRead
#                    do not re-raise socket.error
#                    when sending results, wait indefinitely for the queue
#                    server to be up
# 27 Feb 2013, Paul, fix: also catch errors for getratelimitstatus call
#  1 Mar 2013, Paul, fix queue calls to catch IOError 104 Connection reset
#  4 Mar 2013, Paul, catch BadStatusLine
#
from   httplib    import BadStatusLine, IncompleteRead
import logging
from   operator   import itemgetter
from   socket     import error as SocketError
from   time       import sleep, time

from   twitapi    import TwitError
from   twitparser import TwitParser



class TwitCrawler(object):
	def __init__(self, queue, api, log, config=dict()):
		""" TwitCrawler
		@param queue   TwitQueue instance (possibly TwitQueueClient)
		@param api     TwitAPI instance
		@param log     TwitLog instance
		@param config  optional dictionary with configuration options.
		               api_max_requests: maximum Twitter API requests per crawl
		"""
		self.queue            = queue
		self.api              = api
		self.log              = log
		self.api_max_requests = config.get('api_max_requests', 3) # 3 for debug
	
	def crawl(self):
		""" Crawl and log tweets.
		@return time to wait before next crawl, in seconds.
		"""
		## 1. Request the number of available queries
		
		try:
			lim  = self.api.getratelimitstatus(resources='statuses')
			lim  = lim['resources']['statuses']['/statuses/user_timeline']
			reqn = min(self.api_max_requests, lim['remaining'])
			logging.info('%d Twitter API requests available. Using %d.',
							lim['remaining'], reqn)
		except TwitError, e:
			logging.warn('Twitter says error %d: %s', e.code, e.status)
			return 60 * 60
		except (SocketError, IncompleteRead, BadStatusLine):
			logging.warn('Connection trouble. Maybe Twitter is down/overloaded.')
			return 60 * 60
		
		## 2. Fetch that many twitter IDs to be queried
		
		if not reqn:
			return max(0, lim['reset'] - time()) + 20
		
		try:
			tups      = self.queue.take(reqn)
		except (IOError, SocketError, IncompleteRead, BadStatusLine):
			# IOError [104]: Connection reset by peer
			logging.warn('Couldn\'t reach the queue server. Waiting one hour.')
			return 60 * 60
		
		parser    = TwitParser()
			
		tweets    = []
		new_uids  = set()
		updated   = dict()
		crawled   = 0
		protected = 0
		failed    = 0
		
		## 3. Query the Twitter timelines
		
		try:
			for uid, tid in tups:
				try:
					resp = self.api.getusertimeline(user_id=uid,
									since_id=tid or 1, count=200, trim_user=1,
									exclude_replies=1, contributor_details=0,
									include_rts=1)
				except TwitError, e:
					if e.code < 420:
						logging.debug('Protected profile.')
						protected += 1
						continue
					else:
						# all errors >= 420, back off entirely
						logging.warn('Crawl error %d, %s', e.code, e.status)
						break
				else:
					if len(resp):
						tt = (parser.parsetweet(t) for t in resp)
						# tweet is tuple (tid, uid, ts, msg, refs)
						tt = [t for t in tt if t[0]]
						tt.sort(key=itemgetter(2))
						updated[uid] = tt[-1][0]
						tweets.extend(tt)
					crawled += 1
		
		except (SocketError, IncompleteRead, BadStatusLine):
			logging.warn('Connection trouble. Maybe Twitter is down.')
			return 60 * 60
		
		## 4. Write back the crawled timelines and newly found Twitter IDs
		
		finally:
			failed    = len(tups) - (crawled + protected)
			new_uids  = parser.users_parsed - set(uid for uid,tid in tups)
			numtweets = len(tweets)
			
			# we must keep on trying to update the server with our results...
			done = False
			while not done:
				try:
					logging.info('logging results.')
					qstats = self.queue.update(updated.items(), new_uids)
					if tweets:
						self.log.write_tweets(tweets)
					self.log.write_progress(crawled, protected, failed,
											numtweets, *qstats)
					done = True
				except (IOError, SocketError, IncompleteRead, BadStatusLine):
					logging.error('Couldn\'t reach the queue server.')
					sleep(60 * 60)
		
		## 5. Determine a suitable time for the next run
		
		# update the rate limit info if possible
		for k in lim:
			if 'x-rate-limit-'+k in self.api.response_headers:
				lim[k] = int(self.api.response_headers['x-rate-limit-'+k])
		
		# if there are requests remaining, we will wait 20 seconds
		# if not, we will wait until reset time plus 20 seconds
		return max(0, lim['reset'] - time()) + 20


