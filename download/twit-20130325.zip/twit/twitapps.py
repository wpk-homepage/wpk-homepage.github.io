#
# @author Paul Koppen, http://paulkoppen.com/
# @email  twitwords (a) paulkoppen . com
#
# @version  0.3.0
# @date     20 February 2013
#
# 15 Feb 2013, Paul, first version
# 16 Feb 2013, Paul, twitlog_basename from config
# 19 Feb 2013, Paul, logging to file
#                    crawl loop with timeout returned from crawler
# 20 Feb 2013, Paul, merge qserver.py and crawl.py
#  1 Mar 2013, Paul, removed addHandler for logger. The root logger is now
#                    configured in manage.py
#
from logging     import getLogger, FileHandler, Formatter, INFO, WARN
from os          import path, rename
from signal      import SIGTERM
from socket      import error as SocketError
from sys         import exit, stderr
from time        import sleep, strftime

from config      import *
from twitapi     import TwitAPI
from twitcrawler import TwitCrawler
from twitlog     import TwitLog
from twitqueue   import TwitQueueClient, TwitQueueServer




class AppExitSignal(Exception):
	@classmethod
	def throw(cls, *args):
		raise cls


class App(object):
	def __init__(self, name=None):
		self.name            = name or self.__class__.__name__
		self.logger          = getLogger(self.name)
		self.logger.setLevel(INFO)
		# /var/run is not writable for non-root users. use /tmp instead.
		self.pidfile_path	 = '/tmp/%s.pid' % self.name
		self.pidfile_timeout = 3	# seconds
		self.signal_map = dict([
						(SIGTERM, AppExitSignal.throw),
		#				#(SIGHUP,  'terminate'),
		#				#(SIGUSR1, AppExitSignal.throw),
						])
	
	def run(self):
		self.init()
		self.main_loop()
		self.terminate()
	
	def init(self):
		""" Some initialisation of handles and connections.
		"""
		pass
	
	def main_loop(self):
		""" Main process that runs endelessly until interrupted.
		"""
		# this is just an example setup.
		try:
			pass
		except AppExitSignal:
			return
	
	def terminate(self):
		""" Clean up some handles and connections.
		"""
		pass



################################################################################
###  QSERVER APP
################################################################################

class QServerApp(App):
	
	def __init__(self, *args, **kwargs):
		self.checkdump()
		super(QServerApp, self).__init__(*args, **kwargs)
	
	def init(self):
		""" Initialise the queue server.
		"""
		try:
			self.server = TwitQueueServer(qserver_address, qserver_filename,
							qserver_authkey, item_waittime=q_waittime)
		except SocketError, e:
			# another instance bound to the address
			# most likely the server is already running on this machine
			# so we better just quit
			if e.strerror == 'Address already in use':
				self.logger.info('Server is already running. Exiting.')
			else:
				self.logger.error('socket error: %s', e)
			exit(1)
		except:
			# most likely pickle failed to load the queue, but its file does exist
			# we need to recover from a bad crash
			self.logger.error('Failed to load queue from file.' +
							' Seems previous run crashed.\nPlease inspect.')
			exit(1)
	
	def main_loop(self):
		""" Serve the queue forever (until interrupted).
		"""
		try:
			self.server.serve_forever()
		except AppExitSignal:
			self.logger.info('%s stopping...', self.name)
			return
	
	def terminate(self):
		""" Try to save queue state to disk.
		"""
		dump_filename        = qserver_filename + '.dump'
		self.server.filename = dump_filename
		self.server.save()
		# then move .dump file back, which should be atomic.
		rename(dump_filename, qserver_filename)
		self.logger.info('%s stopped.', self.name)
	
	def checkdump(self):
		""" Detect a previous crash and quit.
		"""
		dump_filename        = qserver_filename + '.dump'
		if path.isfile(dump_filename):
			stderr.write('Found a dump file. Seems previous run crashed.\n' +
							'Please inspect.\n')
			exit(1)



################################################################################
###  CRAWL APP
################################################################################

class CrawlApp(App):
	
	def init(self):
		queue        = TwitQueueClient(qserver_address, qserver_authkey)
		api          = TwitAPI(**twitter_apikeys)
		# NB make sure folder exists!
		log          = TwitLog(node(), twitlog_tweets, twitlog_network, twitlog_stats)
		config       = dict(api_max_requests=twitter_maxrequests)
		self.crawler = TwitCrawler(queue, api, log, config)
	
	def main_loop(self):
		try:
			while True:
				self.logger.info('%s commencing.', self.name)
				timewait = self.crawler.crawl()
				self.logger.info('%s going to sleep for %d seconds.',
									self.name, timewait)
				sleep(timewait)
		except AppExitSignal:
			self.logger.info('%s stopping...', self.name)
			return
	
	def terminate(self):
		# I don't think there is anything we can do here.
		# Well, that is witout heavily changing the crawler so we can stop it
		# and save all its intermediate results.
		self.logger.info('%s stopped.', self.name)




