#
# @author Paul Koppen, http://paulkoppen.com/
# @email  twitwords (a) paulkoppen . com
#
# @version 0.3.0
# @date    15 February 2013
#
# 14 Feb 2013, Paul, first version
# 15 Feb 2013, Paul, added Twitter API configuration directives
# 16 Feb 2013, Paul, added twitlog_basename
# 20 Feb 2013, Paul, added app_logfilename
#  1 Mar 2013, Paul, changed app_logfilename to manage_logfile, because in the
#                    now setup manage.py configures the root logger and apps
#                    only configure their logging name and level.
#
from os         import getcwd, path
from platform   import node
from time       import strftime



### LOGGING

# N.B. make sure those folders exist!
twitlog_fld     = path.join(getcwd(), 'crawled')
twitlog_tweets  = twitlog_fld + '%%s-%s.tweets'  % node()	# %%s will be date
twitlog_network = twitlog_fld + '%%s-%s.network' % node()
twitlog_stats   = twitlog_fld + 'crawl-%s.stats'


### QUEUE CLIENT / SERVER

qserver_address  = ('127.0.0.1', 7000)		# local
qserver_authkey  = 'some optional characters to have an encrypted communication'
qserver_filename = path.join(getcwd(), 'queue.state')

q_waittime       = 60 * 60 * 24 * 7
q_bootstrap      = [559666191,492480323,246257298]


### MANAGE.PY

# %%s is app name
manage_logfile   = path.join(getcwd(), 'log/%%s-%s.log' % node())


### TWITTER

twitter_maxrequests = 10	# for debug, set to 3, max is 180 or 300

from twitter_keys import keys as twitter_apikeys	# fill in your keys there!!


