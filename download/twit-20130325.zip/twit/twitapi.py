#
# @author Paul Koppen, http://paulkoppen.com/
# @email  twitwords (a) paulkoppen . com
#
# @version 0.3.0
# @date    15 February 2013
#
# 15 Feb 2013, Paul, added some extra error handling
#
from   json    import loads
import logging
from   oauth2  import Client, Consumer, Token
from   urllib  import urlencode

__all__ = ['TwitAPI', 'TwitError', 'api_table']


base_url = 'https://api.twitter.com/%(version)s%(path)s.json'

api_table = {
	'getratelimitstatus': {
		# https://dev.twitter.com/docs/api/1.1/get/application/rate_limit_status
		'url': '/application/rate_limit_status',
		'method': 'GET',
	},
	'getusertimeline': {
		# https://dev.twitter.com/docs/api/1.1/get/statuses/user_timeline
		'url': '/statuses/user_timeline',
		'method': 'GET',
	},
	
	'users_show': {
		# https://dev.twitter.com/docs/api/1.1/get/users/show
		'url': '/users/show',
		'method': 'GET',
	},
	'users_lookup': {
		# https://dev.twitter.com/docs/api/1.1/get/users/lookup
		'url': '/users/lookup',
		'method': 'GET',
	},
	'users_search': {
		# https://dev.twitter.com/docs/api/1.1/get/users/search
		'url': '/users/search',	# required arg: q
		'method': 'GET',
	},
}

# from https://dev.twitter.com/docs/error-codes-responses
twitter_http_status_codes = {
	200: ('OK', 'Success!'),
	304: ('Not Modified', 'There was no new data to return.'),
	400: ('Bad Request', 'The request was invalid. An accompanying error message will explain why. This is the status code will be returned during version 1.0 rate limiting. In API v1.1, a request without authentication is considered invalid and you will get this response.'),
	401: ('Unauthorized', 'Authentication credentials were missing or incorrect.'),
	403: ('Forbidden', 'The request is understood, but it has been refused or access is not allowed. An accompanying error message will explain why. This code is used when requests are being denied due to update limits.'),
	404: ('Not Found', 'The URI requested is invalid or the resource requested, such as a user, does not exists. Also returned when the requested format is not supported by the requested method.'),
	406: ('Not Acceptable', 'Returned by the Search API when an invalid format is specified in the request.'),
	420: ('Enhance Your Calm', 'Returned by the version 1 Search and Trends APIs when you are being rate limited.'),
	422: ('Unprocessable Entity', 'Returned when an image uploaded to POST account/update_profile_banner is unable to be processed.'),
	429: ('Too Many Requests', 'Returned in API v1.1 when a request cannot be served due to the application\'s rate limit having been exhausted for the resource. See Rate Limiting in API v1.1.'),
	500: ('Internal Server Error', 'Something is broken. Please post to the group so the Twitter team can investigate.'),
	502: ('Bad Gateway', 'Twitter is down or being upgraded.'),
	503: ('Service Unavailable', 'The Twitter servers are up, but overloaded with requests. Try again later.'),
	504: ('Gateway Timeout', 'The Twitter servers are up, but the request couldn\'t be serviced due to some failure within our stack. Try again later.'),
	600: ('Error, but clueless', 'We have no idea what is going on, but it just went wrong.'),
}


class TwitError(StandardError):
	def __init__(self, num):
		super(StandardError, self).__init__(num)
		status, message = twitter_http_status_codes[num]
		self.code       = num
		self.status     = status
		self.message    = message
	def __str__(self):
		return 'TwitError %d: %s' % (self.code, self.status)


class TwitAPI(object):
	def __init__(self, app_key, app_secret, oauth_token, oauth_token_secret,
									headers=None, version='1.1'):
		consumer              = Consumer(app_key, app_secret)
		token                 = Token(oauth_token, oauth_token_secret)
		self.client           = Client(consumer, token)
		self.request_headers  = headers
		self.response_headers = dict()
		self.response         = dict()
		for fn,parms in api_table.items():
			self.__dict__[fn] = self._makeFn(version, parms)
	
	def _makeFn(self, version, parms):
		url    = base_url % {'version':version, 'path':parms['url']}
		method = parms['method']
		return lambda **kwargs: self.fetch(url, method, **kwargs)
	
	def fetch(self, url, method, **kwargs):
		""" Fetch info from the API using JSON.
		@param   url       API endpoint (string)
		@param   method    Request method (GET/POST)
		**kwargs postdata  Data to be sent over in the request in key-value form
		@return  obj       JSON object (dict)
		"""
		if method.upper() == 'POST':
			body = urlencode(kwargs)
		else:
			url  = url + '?' + urlencode(kwargs)
			body = ''
		logging.debug('%s %s\n%s', method, url, body)
		
		resp, content = self.client.request(    url,
							method            = method,
							body              = body,
							headers           = self.request_headers,
							#force_auth_header = True,
							)
		logging.debug(resp)
		logging.debug(content)
		
		self.response_headers = resp
		try:
			content = loads(content)
			status  = int(resp.get('status', 600))
		except ValueError:
			raise TwitError(500)
		finally:
			self.response = content
		
		if status < 400:
			return self.response
		else:
			raise TwitError(status)




