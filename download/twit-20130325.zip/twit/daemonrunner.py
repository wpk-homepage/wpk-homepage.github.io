#
# @author Paul Koppen, http://paulkoppen.com/
# @email  twitwords (a) paulkoppen . com
#
# @version  0.3.0
# @date     20 February 2013
# @requires python-daemon (Linux only)
#
# 20 Feb 2013, Paul, first version
#  1 Mar 2013, Paul, changed MyDaemonRunner to preserve the root logger
#
from daemon         import DaemonContext
from daemon.pidfile import TimeoutPIDLockFile
from errno          import ESRCH
from lockfile       import LockTimeout
from logging        import root
from os             import getpid, kill, path
from signal         import SIG_DFL, SIGTERM
from sys            import exit



class MyDaemonRunner(object):
	""" Service to start and stop a daemon.
	Heavily borrowed code from python-daemon's DaemonRunner.
	"""
	
	def __init__(self, app):
		""" Set up the parameters of a new runner.
		
		The `app` argument must have the following attributes:
		
		* `pidfile_path`: Absolute filesystem path to a file that
		  will be used as the PID file for the daemon. If
		  ``None``, no PID file will be used.
		
		* `pidfile_timeout`: Used as the default acquisition
		  timeout value supplied to the runner's PID lock file.
		
		* `run`: Callable that will be invoked when the daemon is
		  started.
		
		* `signal_map`: Optional dictionary to map signals to actions.
		"""
		self.app     = app
		self.logger  = app.logger	# borrow the logger
		self.pidfile = MyDaemonRunner.make_pidlockfile(
						app.pidfile_path, app.pidfile_timeout)
		preserve     = [h.stream for h in app.logger.handlers + root.handlers]
		self.context = DaemonContext(pidfile=self.pidfile, umask=0o066,
						files_preserve=preserve)
		for attr in ('signal_map','stdin','stdout','stderr'):
			if hasattr(app, attr):
				setattr(self.context, attr, getattr(app, attr))
	
	def _terminate_daemon_process(self):
		""" Terminate the daemon process specified in the current PID file.
		"""
		pid = self.pidfile.read_pid()
		try:
			kill(pid, SIGTERM)
			self.logger.info('PID %d stopped.', self.pidfile.read_pid())
		except OSError, exc:
			self.logger.error('Failed to terminate %d: %s', pid, exc)
	
	def start(self):
		""" Open the daemon context and run the application.
		"""
		if MyDaemonRunner.is_pidfile_stale(self.pidfile):
			self.pidfile.break_lock()
		try:
			self.context.open()
		except LockTimeout:
			self.logger.info('%s is already running' +
							' (could not acquire lock). Exiting.',
							self.app.name)
			# just return. everything is fine.
		else:
			self.logger.info('%s daemonized with pid %d.',
							self.app.name, getpid())
			self.app.run()
	
	def stop(self):
		""" Exit the daemon process specified in the current PID file.
		"""
		if not self.pidfile.is_locked():
			pidfile_path = self.pidfile.path
			self.logger.info('PID file %r not locked. OK.' % pidfile_path)
		elif MyDaemonRunner.is_pidfile_stale(self.pidfile):
			self.pidfile.break_lock()
		else:
			self._terminate_daemon_process()
	
	def restart(self):
		""" Stop, then start.
		"""
		self.stop()
		self.start()
	
	@staticmethod
	def make_pidlockfile(filename, acquire_timeout):
		""" Make a PIDLockFile instance with the given filesystem path.
		"""
		if not isinstance(filename, basestring):
			raise ValueError("Not a filesystem path: %r" % filename)
		if not path.isabs(filename):
			raise ValueError("Not an absolute path: %r" % filename)
		return TimeoutPIDLockFile(filename, acquire_timeout)
	
	@staticmethod
	def is_pidfile_stale(pidfile):
		""" Determine whether a PID file is stale.
		
		Return ``True`` ("stale") if the contents of the PID file are
		valid but do not match the PID of a currently-running process;
		otherwise return ``False``.
		"""
		result      = False
		pidfile_pid = pidfile.read_pid()
		if pidfile_pid is not None:
			try:
				kill(pidfile_pid, SIG_DFL)
			except OSError, e:
				if e.errno == ESRCH:
				    # The specified PID does not exist
				    result = True
		return result



