#!/usr/bin/env python
#
# @author Paul Koppen, http://paulkoppen.com/
# @email  twitwords (a) paulkoppen . com
#
# @version  0.3.0
# @date     14 February 2013
# @requires python-daemon (Linux only)
#
# 14 Feb 2013, Paul, first version of TwitQueue as server
# 16 Feb 2013, Paul, added q_waittime
# 19 Feb 2013, Paul, logging to file
# 20 Feb 2013, Paul, one manage.py to operate crawlers and queue together
#  1 Mar 2013, Paul, simplified argument parsing in __main__
#                    added root logger configuration
#                    root logger has TimedRotatingFileHandler
#
"""
manage.py [crawl|queue] [start|stop]
manage.py queue [bootstrap|save|stats]

Start and stop operate a daemon process for the crawler / queue.
They log to files in the folder log/

Bootstrap, save, and stats provide access to the queue, placing initial values
on it, saving it to disk, and printing statistics about it respectively.
"""
from logging          import getLogger, Formatter, DEBUG, INFO, WARN, ERROR
from logging.handlers import TimedRotatingFileHandler
from socket           import error as SocketError
from os               import isatty
from sys              import argv, exit, stderr, stdout

from config           import *
from daemonrunner     import MyDaemonRunner
from twitapps         import CrawlApp, QServerApp
from twitqueue        import TwitQueueClient



def printusage():
	""" Print usage (in docstring) and return exit value 2.
	"""
	stdout.write(__doc__)
	stdout.write('\n')

def configrootlog(appname, level=WARN):
	""" Configure the root logger.
	@param appname  Application name will be part of the log's filename.
	@param level    Warning level for messages to appear in the logs.
	"""
	logfile   = manage_logfile % appname
	handler   = TimedRotatingFileHandler(logfile,'D',1,3,delay=1)
	formatter = Formatter('%(asctime)s:%(levelname)s:%(name)s -- %(message)s',
							datefmt='%Y-%m-%d %H:%M')
	logger    = getLogger()
	logger.setLevel(level)
	handler.setFormatter(formatter)
	logger.addHandler(handler)



################################################################################
###  MAIN
################################################################################

if __name__ == '__main__':
	command       = set(map(str.lower, argv[1:]))
	apps          = dict(crawl=CrawlApp, queue=QServerApp)
	runneractions = set(['start','stop'])
	clientactions = set(['bootstrap','stats','save','quit'])
	runner        = None
	retval        = 1
	try:
		if '--help' in command:
			printusage()
			retval = 0
		# queue/crawl start/stop
		elif runneractions & command:
			try:
				appclass  = (apps[cmd] for cmd in apps if cmd in command).next()
			except StopIteration:
				retval    = 2
			else:
				# configure root logger
				configrootlog(appclass.__name__, INFO)
				# set up and run the application as daemon
				runner   = MyDaemonRunner(appclass())
				action   = list(runneractions & command)[0]
				getattr(runner, action)()	# "start" runs forever
				retval   = 0
		# queue bootstrap/stats/save/quit
		elif 'queue' in command and (clientactions & command):
			client  = TwitQueueClient(qserver_address, qserver_authkey)
			action  = list(clientactions & command)[0]
			try:
				if   'bootstrap' == action:
					client.update(dict(), q_bootstrap)
				elif 'save' == action:
					client.save()
				elif 'stats' == action:
					stdout.write(('Unique twitter IDs: %d\n' +
							'Crawled timelines:  %d\n') % client.stats())
				elif 'quit' == action:
					client.quit()
				retval = 0
			except SocketError, e:
				if e.strerror == 'Connection refused':
					stderr.write('Connection refused. Server down?\n')
					retval = 0
				else:
					raise(e)
	except Exception, e:
		error = stderr.write if isatty(stderr.fileno()) else runner.logger.error
		error('"%s" failed because of %s %s\n' % (
							' '.join(command), e.__class__, e))
	finally:
		# the writes will do nothing when action == 'start' because the daemon
		# closes stdout and stderr. but that is OK because by the time the
		# daemon process arrives at this point, it is so much later that such a
		# message would only confuse us. Any errors during the daemon execution
		# are logged anyway.
		if retval == 2:
			stdout.write('Invalid command. Run manage.py --help for options.\n')
		elif retval != 0:
			stderr.write('"%s" failed.\n' % ' '.join(command))
		elif retval == 0:
			stdout.write('"%s" OK.\n' % ' '.join(command))
		exit(retval)





