#
# @author Paul Koppen, http://paulkoppen.com/
# @email  twitwords (a) paulkoppen . com
#
# @version 0.3.0
# @date    6 December 2012
#
# 23 Oct 2012, Paul, words now include digits
#  7 Jan 2013, Paul, entities are replaced by specific characters
#  8 Jan 2013, Paul, adjusted regexes
#                    added media entity
# 15 Jan 2013, Paul, added timestamp
#                    fixed users_parsed
# 17 Jan 2013, Paul, fixed mentions to really exclude uid
#
from   codecs     import open
from   HTMLParser import HTMLParser
import logging
from   time       import strptime
import re

__all__ = ['TwitParser']


htmlparser     = HTMLParser()
tweet_regexes  = [(re.compile(ex,re.UNICODE),rep) for ex,rep in [
    # urls not caught by them Twitter folks
    (r'(http[s]?:\/.+?)(\s|\.\s|$|\.$)', ' \2'),
    (r'(www\.)?\b\w+\.(com|net|org|mobi|nl|es|de|fr|co\.uk|ac\.uk|be|se|fi|no|dk|pl|hu|cz|pt)\b', '$$$~'),
    # abbreviations -> without periods
    (r'\b[a-zA-Z]\.(?:[a-zA-Z]\.)+[a-zA-Z]?(?:[!?:;\r\n, ]|$)', lambda m: m.group(0).replace('.','')),
    # numbers (in all their forms) -> '0'
    (r'(?:[-]?[.]?\d)(?:[,.:/-]?\d)*', '$$$0'),
    # commas / repeated spaces -> single space
    (r'[;, ]+', ' '),
    # end of sentence -> newline
    (r'\s*[!?.:\r\n]+[!?.:\r\n\s]*', '\n'),
]]
# regex got a bit annoying to allow for things like "$$$@'s birthday" and "$$$0pm"
re_word        = re.compile(r"(?:\$\$\$[~#@+0])?(?:[^\W_]|[&'-])+|(?:\$\$\$[~#@+0])", re.UNICODE)
tweet_entities = dict([
	('urls', '$$$~'),
	('hashtags', '$$$#'),
	('user_mentions', '$$$@'),
	('media', '$$$+'),
])


class TwitParser(object):
	def __init__(self):
		self.users_parsed  = set()
		self.tweets_parsed = 0
	
	def stats(self):
		return (len(self.users_parsed), self.tweets_parsed)
	
	def parsetweet(self, obj):
		""" Parse a JSON tweet extracting author,tweetid, message, usermentions.
		@param  obj (dict)  Tweet object received from the Twitter API.
		@return tuple       Tuple of (tid, uid, ts, msg, refs),
			                tid = tweet id, uid = user id, ts = struct_time,
							msg = tweet text, refs = list of mentioned user ids
		"""
		uid      = obj['user']['id']
		tid      = obj['id']
		text     = obj['text']
		mentions = []
		# check if tweet is retweet and last word seems truncated
		fixrt    = 'text' in obj.get('retweeted_status', dict()) \
					and text[-3:] != obj['retweeted_status']['text'][-3:]
		# find user ids
		empty_status = {'user':{'id':None}}
		mentions.append(obj.get('in_reply_to_user_id_str', None))
		mentions.append(obj.get('retweeted_status', empty_status)['user']['id'])
		mentions.extend(m['id'] for m in obj['entities']['user_mentions'])
		mentions = [userid for userid in mentions if userid and (userid != uid)]
		# parse text
		# -- replace entities
		entities = obj['entities']
		rep      = [e['indices']+[tweet_entities.get(ent,ent)]
					for ent in entities for e in entities[ent]]
		rep.sort(reverse=True)
		for start,end,char in rep:
			text = text[:start] + char + text[end:]
		# -- fix encoding
		text     = htmlparser.unescape(text.lower())
		text     = text.replace(u'\u2019', "'")
		# -- fix missed items (and punctuation)
		for ex,rep in tweet_regexes:
			text = re.sub(ex, rep, text)
		# -- fix punctuation (remainder)
		phrases  = text.strip(u" \r\n").split('\n')
		for i,phrase in enumerate(phrases):
			words      = re.findall(re_word, phrase)
			words      = [w.strip(u"-'$&") for w in words]
			if fixrt and i == len(phrases)-1:
				# if it looks like last word is truncated in retweet
				# we'll just remove the word entirely
				words  = words[:-1]
			phrases[i] = u' '.join(w for w in words if w)
		text     = u'\n'.join(p for p in phrases if p)
		# -- @todo: get timestamp
		ts = strptime(obj['created_at'],'%a %b %d %H:%M:%S +0000 %Y')
		# done.
		self.users_parsed.update(mentions + [uid])
		self.tweets_parsed += 1
		return (tid, uid, ts, text, mentions)




