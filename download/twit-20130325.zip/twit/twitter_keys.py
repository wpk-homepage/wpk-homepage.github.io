#
#
from platform import node
from random   import choice


apps = dict(
	yourmachinename = dict(
		app_key='',
		app_secret='',
		oauth_token='',
		oauth_token_secret='',
	),
)

keys = apps.get(node(), apps[choice(apps.keys())])

